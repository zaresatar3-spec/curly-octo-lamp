# API baseline

All public APIs will be versioned under `/api/v1`. Phase 1 currently exposes only operational endpoints:

- `GET /healthz`: process is alive; does not prove dependencies are available.
- `GET /readyz`: checks PostgreSQL and Redis with short timeouts.

Future endpoints must define request/response schemas, RBAC permission, audit action, OpenAPI operation, validation rules, idempotency where needed, and tests before being considered complete.
