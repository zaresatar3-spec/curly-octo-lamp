# Initial RBAC matrix

| Capability | Super Admin | Admin | Reseller | Support | Read-only | End User |
|---|---:|---:|---:|---:|---:|---:|
| Global settings/licensing | Yes | Limited | No | No | Read | No |
| Manage admins/roles | Yes | Limited | No | No | Read | No |
| Manage nodes/inbounds | Yes | Yes | No by default | No | Read | No |
| Manage own reseller tree | Yes | Yes | Scoped | No | Read | No |
| Manage end users | Yes | Yes | Scoped | Scoped support | Read | Own profile |
| View financial ledger | Yes | Yes | Own scope | No | Read | Own orders |
| Approve payments/refunds | Yes | Policy-based | Scoped policy | No | Read | No |
| View audit logs | Yes | Yes | Own scope | Limited | Read | No |
| Manage own subscription | Yes | Yes | Scoped | Support flow | Read | Yes |

This matrix is a design baseline only. Authorization middleware and negative tests are required before production.
