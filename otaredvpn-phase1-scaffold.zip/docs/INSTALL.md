# Development install

1. Install Docker Engine and the Compose plugin.
2. Copy `.env.example` to `.env`.
3. Replace the local-only sample passwords in `.env`.
4. Run `make dev`.
5. Check `curl http://127.0.0.1:8080/healthz` and `curl http://127.0.0.1:8080/readyz`.
6. Run `make logs`; stop with `make down`.

This is not the production one-line installer. Production installation requires a tagged release, checksum/signature verification, supported-OS checks, TLS/domain setup, backup, rollback, license activation, and an end-to-end installation test.
