# Data model

The initial migration is a baseline schema covering identity/RBAC, reseller hierarchy, users/subscriptions/plans, nodes/inbounds/protocol profiles, partitioned traffic events and rollups, wallets/transactions, orders/payments/coupons, tickets, bot sessions, audit logs, settings, licensing, backups, notifications, templates and an event outbox.

## Important notes
- Amounts are integer minor units plus ISO currency; the UI must explicitly distinguish IRR and Toman.
- Wallet transactions are immutable records, but this phase does not yet implement double-entry accounting or transactional balance updates.
- `traffic_events` has a default partition for local bootstrap. Production should create time-based partitions and retention policies.
- Reseller tree uses PostgreSQL `ltree`; application logic must maintain `tree_path` transactionally.
- Secrets should be envelope-encrypted in production; `secret_encrypted` is metadata, not encryption by itself.
- Validate and review every migration against a disposable database before production use.
