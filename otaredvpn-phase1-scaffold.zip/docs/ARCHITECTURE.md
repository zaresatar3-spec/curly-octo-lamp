# Architecture

## Service topology
```mermaid
flowchart TB
  Web[Next.js Web UI] -->|HTTPS /api/v1| Master[Go Master API]
  Master --> PG[(PostgreSQL)]
  Master --> Redis[(Redis)]
  Master -->|mTLS + gRPC| Node1[otared-node 1]
  Master -->|mTLS + gRPC| NodeN[otared-node N]
  Node1 --> Xray[Xray-core]
  Node1 --> Sing[sing-box]
  Master --> License[Separate License Authority]
  Bots[Telegram / Bale / Eitaa adapters] --> Master
```

## Request flow
```mermaid
sequenceDiagram
  participant C as Client
  participant W as Web UI
  participant M as Master API
  participant D as PostgreSQL
  C->>W: HTTPS request
  W->>M: Versioned API request
  M->>M: Authenticate + authorize (planned)
  M->>D: Read/write transaction
  D-->>M: Result
  M-->>W: JSON response
  W-->>C: Rendered page
```

## Traffic accounting pipeline
```mermaid
flowchart LR
  Core[Core stats API] --> Agent[Node agent]
  Agent -->|batched events| Master[Master ingestion]
  Master --> Queue[Redis/worker queue]
  Queue --> Raw[(Partitioned traffic events)]
  Raw --> Rollup[Aggregation worker]
  Rollup --> Summary[(Traffic rollups)]
```

## Bot flow
```mermaid
sequenceDiagram
  participant U as User
  participant B as Messenger Bot
  participant M as Master API
  participant P as Payment Provider
  U->>B: Buy / renew
  B->>M: Create order
  M-->>B: Checkout instructions
  B->>P: Payment initiation (planned adapter)
  P-->>M: Signed webhook (planned)
  M->>M: Verify signature + idempotency
  M-->>B: Fulfillment event
  B-->>U: Subscription details
```

## License flow
```mermaid
sequenceDiagram
  participant I as Installer
  participant A as License Authority
  participant S as Customer Server
  I->>A: Activate key + server fingerprint
  A-->>I: Signed license document
  S->>A: Periodic validation
  A-->>S: Validity / revocation status
  Note over S,A: Offline grace policy must be explicit
```

## Design principles
- Master is the source of truth; node agents apply desired state.
- Node commands are authenticated, authorized, versioned and idempotent.
- Traffic ingestion must be asynchronous and bounded.
- Money movements use immutable ledger entries and idempotency keys.
- Secrets are never committed; production secret encryption/key rotation is a later deliverable.
- This scaffold does not yet implement the planned flows.
