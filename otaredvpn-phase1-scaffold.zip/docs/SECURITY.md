# Security baseline and gaps

## Baseline
- Development ports bind to loopback only.
- Sample environment variables are placeholders and must be changed.
- Master uses request timeouts and graceful shutdown.
- Database access uses parameterized driver APIs when queries are added.
- Node command contract is only a proto draft; no unauthenticated command server exists yet.

## Not implemented yet
Authentication, Argon2id password hashing, refresh-token rotation, TOTP, CSRF, RBAC middleware, audit middleware, CSP/security headers, API rate limiting, secret encryption, mTLS enrollment, signed license verification, backup encryption workflow, dependency scanning and production firewall policy.

Never expose this Phase 1 Compose stack publicly. Do not store production credentials in Git.
