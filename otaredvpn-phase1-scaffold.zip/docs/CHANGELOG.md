# Changelog

## Unreleased — Phase 1 scaffold
- Added initial service topology and documentation.
- Added starter PostgreSQL schema and gRPC contract draft.
- Added minimal Go health/readiness service and web placeholder.
- Not yet production-ready; see SECURITY.md and README.md.
