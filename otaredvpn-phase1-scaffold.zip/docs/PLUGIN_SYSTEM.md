# Plugin and event design

Phase 1 reserves an `event_outbox` table for transactional event publication. Planned events use stable versioned names (for example `subscription.created.v1`) and carry schema-versioned payloads. Consumers must be idempotent and retry-safe.

External plugins should eventually use signed manifests, explicit permissions/scopes, version compatibility declarations and sandboxing boundaries. Do not load arbitrary Go plugins into the master process in the first release. Prefer adapters behind narrow interfaces and outbound webhooks signed with rotating secrets.
