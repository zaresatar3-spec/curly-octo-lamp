DROP TABLE IF EXISTS event_outbox, message_templates, notifications, backups,
license_activations, licenses, app_settings, audit_logs, bot_sessions,
ticket_messages, tickets, coupons, payments, orders, wallet_transactions, wallets,
traffic_rollups, traffic_events, protocol_profiles, inbounds, nodes, node_groups,
subscriptions, plans, end_users, resellers, role_permissions, admin_roles,
permissions, roles, admins CASCADE;
DROP EXTENSION IF EXISTS ltree;
DROP EXTENSION IF EXISTS pgcrypto;
