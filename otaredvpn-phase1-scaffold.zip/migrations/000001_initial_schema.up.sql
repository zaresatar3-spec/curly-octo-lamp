CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE EXTENSION IF NOT EXISTS ltree;

CREATE TABLE admins (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL UNIQUE,
  password_hash text NOT NULL,
  display_name text NOT NULL,
  is_active boolean NOT NULL DEFAULT true,
  totp_secret_enc bytea,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text NOT NULL UNIQUE,
  name text NOT NULL
);
CREATE TABLE permissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text NOT NULL UNIQUE,
  description text NOT NULL
);
CREATE TABLE admin_roles (
  admin_id uuid NOT NULL REFERENCES admins(id) ON DELETE CASCADE,
  role_id uuid NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
  PRIMARY KEY (admin_id, role_id)
);
CREATE TABLE role_permissions (
  role_id uuid NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
  permission_id uuid NOT NULL REFERENCES permissions(id) ON DELETE CASCADE,
  PRIMARY KEY (role_id, permission_id)
);

CREATE TABLE resellers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  parent_id uuid REFERENCES resellers(id) ON DELETE RESTRICT,
  tree_path ltree,
  name text NOT NULL,
  email text UNIQUE,
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active','suspended','closed')),
  wallet_mode text NOT NULL DEFAULT 'prepaid' CHECK (wallet_mode IN ('prepaid','postpaid','credit')),
  debt_limit_minor bigint NOT NULL DEFAULT 0 CHECK (debt_limit_minor >= 0),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX resellers_tree_path_gist ON resellers USING gist(tree_path);
CREATE INDEX resellers_parent_id_idx ON resellers(parent_id);

CREATE TABLE end_users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  reseller_id uuid REFERENCES resellers(id) ON DELETE SET NULL,
  username text NOT NULL UNIQUE,
  email text,
  telegram_id text,
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active','suspended','expired','deleted')),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE plans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text NOT NULL UNIQUE,
  name text NOT NULL,
  duration_seconds bigint CHECK (duration_seconds IS NULL OR duration_seconds > 0),
  traffic_bytes bigint CHECK (traffic_bytes IS NULL OR traffic_bytes >= 0),
  max_devices integer NOT NULL DEFAULT 1 CHECK (max_devices > 0),
  speed_limit_bps bigint CHECK (speed_limit_bps IS NULL OR speed_limit_bps > 0),
  price_minor bigint NOT NULL CHECK (price_minor >= 0),
  currency char(3) NOT NULL DEFAULT 'IRR',
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES end_users(id) ON DELETE RESTRICT,
  plan_id uuid NOT NULL REFERENCES plans(id) ON DELETE RESTRICT,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','active','expired','suspended','cancelled')),
  starts_at timestamptz,
  expires_at timestamptz,
  traffic_limit_bytes bigint CHECK (traffic_limit_bytes IS NULL OR traffic_limit_bytes >= 0),
  traffic_used_bytes bigint NOT NULL DEFAULT 0 CHECK (traffic_used_bytes >= 0),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX subscriptions_user_status_idx ON subscriptions(user_id, status);

CREATE TABLE node_groups (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  description text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE nodes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  group_id uuid REFERENCES node_groups(id) ON DELETE SET NULL,
  name text NOT NULL,
  address text NOT NULL,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','online','degraded','offline','disabled')),
  agent_version text,
  certificate_fingerprint text UNIQUE,
  last_seen_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(address, name)
);
CREATE TABLE inbounds (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  node_id uuid NOT NULL REFERENCES nodes(id) ON DELETE CASCADE,
  name text NOT NULL,
  core text NOT NULL CHECK (core IN ('xray','sing-box')),
  listen_port integer NOT NULL CHECK (listen_port BETWEEN 1 AND 65535),
  protocol text NOT NULL,
  enabled boolean NOT NULL DEFAULT true,
  config_version bigint NOT NULL DEFAULT 1,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(node_id, listen_port)
);
CREATE TABLE protocol_profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  inbound_id uuid NOT NULL REFERENCES inbounds(id) ON DELETE CASCADE,
  name text NOT NULL,
  schema_version integer NOT NULL DEFAULT 1,
  config jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE traffic_events (
  observed_at timestamptz NOT NULL,
  id bigserial,
  node_id uuid NOT NULL REFERENCES nodes(id) ON DELETE RESTRICT,
  user_id uuid NOT NULL REFERENCES end_users(id) ON DELETE RESTRICT,
  subscription_id uuid REFERENCES subscriptions(id) ON DELETE SET NULL,
  inbound_id uuid REFERENCES inbounds(id) ON DELETE SET NULL,
  upload_bytes bigint NOT NULL DEFAULT 0 CHECK (upload_bytes >= 0),
  download_bytes bigint NOT NULL DEFAULT 0 CHECK (download_bytes >= 0),
  PRIMARY KEY (observed_at, id)
) PARTITION BY RANGE (observed_at);
CREATE TABLE traffic_events_default PARTITION OF traffic_events DEFAULT;
CREATE INDEX traffic_events_user_time_idx ON traffic_events(user_id, observed_at DESC);
CREATE INDEX traffic_events_node_time_idx ON traffic_events(node_id, observed_at DESC);

CREATE TABLE traffic_rollups (
  bucket_start timestamptz NOT NULL,
  bucket_width_seconds integer NOT NULL,
  user_id uuid NOT NULL REFERENCES end_users(id) ON DELETE CASCADE,
  node_id uuid REFERENCES nodes(id) ON DELETE SET NULL,
  upload_bytes bigint NOT NULL DEFAULT 0,
  download_bytes bigint NOT NULL DEFAULT 0,
  PRIMARY KEY(bucket_start, bucket_width_seconds, user_id, node_id)
);

CREATE TABLE wallets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  reseller_id uuid UNIQUE REFERENCES resellers(id) ON DELETE CASCADE,
  currency char(3) NOT NULL DEFAULT 'IRR',
  balance_minor bigint NOT NULL DEFAULT 0,
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE wallet_transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  wallet_id uuid NOT NULL REFERENCES wallets(id) ON DELETE RESTRICT,
  idempotency_key text NOT NULL UNIQUE,
  kind text NOT NULL CHECK (kind IN ('credit','debit','commission','refund','adjustment')),
  amount_minor bigint NOT NULL CHECK (amount_minor > 0),
  currency char(3) NOT NULL,
  reference_type text,
  reference_id uuid,
  note text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX wallet_transactions_wallet_time_idx ON wallet_transactions(wallet_id, created_at DESC);

CREATE TABLE orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES end_users(id) ON DELETE SET NULL,
  reseller_id uuid REFERENCES resellers(id) ON DELETE SET NULL,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','paid','failed','cancelled','refunded')),
  currency char(3) NOT NULL DEFAULT 'IRR',
  subtotal_minor bigint NOT NULL CHECK (subtotal_minor >= 0),
  discount_minor bigint NOT NULL DEFAULT 0 CHECK (discount_minor >= 0),
  total_minor bigint NOT NULL CHECK (total_minor >= 0),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL REFERENCES orders(id) ON DELETE RESTRICT,
  provider text NOT NULL,
  provider_reference text,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','authorized','paid','failed','refunded')),
  amount_minor bigint NOT NULL CHECK (amount_minor >= 0),
  currency char(3) NOT NULL,
  idempotency_key text NOT NULL UNIQUE,
  verified_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE coupons (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text NOT NULL UNIQUE,
  discount_kind text NOT NULL CHECK (discount_kind IN ('fixed','percent')),
  discount_value bigint NOT NULL CHECK (discount_value > 0),
  max_redemptions integer CHECK (max_redemptions IS NULL OR max_redemptions > 0),
  expires_at timestamptz,
  is_active boolean NOT NULL DEFAULT true
);
CREATE TABLE tickets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES end_users(id) ON DELETE SET NULL,
  reseller_id uuid REFERENCES resellers(id) ON DELETE SET NULL,
  subject text NOT NULL,
  status text NOT NULL DEFAULT 'open' CHECK (status IN ('open','waiting','resolved','closed')),
  priority text NOT NULL DEFAULT 'normal' CHECK (priority IN ('low','normal','high','urgent')),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE ticket_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ticket_id uuid NOT NULL REFERENCES tickets(id) ON DELETE CASCADE,
  author_type text NOT NULL CHECK (author_type IN ('admin','reseller','user','system')),
  author_id uuid,
  body text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE bot_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  platform text NOT NULL CHECK (platform IN ('telegram','bale','eitaa')),
  external_user_id text NOT NULL,
  state jsonb NOT NULL DEFAULT '{}'::jsonb,
  expires_at timestamptz NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(platform, external_user_id)
);
CREATE TABLE audit_logs (
  id bigserial PRIMARY KEY,
  actor_type text NOT NULL,
  actor_id uuid,
  action text NOT NULL,
  resource_type text NOT NULL,
  resource_id text,
  request_id text,
  ip_address inet,
  user_agent text,
  before_state jsonb,
  after_state jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX audit_logs_resource_time_idx ON audit_logs(resource_type, resource_id, created_at DESC);
CREATE INDEX audit_logs_actor_time_idx ON audit_logs(actor_type, actor_id, created_at DESC);

CREATE TABLE app_settings (
  key text PRIMARY KEY,
  value jsonb NOT NULL,
  secret_encrypted boolean NOT NULL DEFAULT false,
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE licenses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  license_key_hash text NOT NULL UNIQUE,
  tier text NOT NULL CHECK (tier IN ('starter','pro','enterprise','unlimited')),
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','active','suspended','revoked','expired')),
  max_users integer,
  max_nodes integer,
  max_resellers integer,
  expires_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE license_activations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  license_id uuid NOT NULL REFERENCES licenses(id) ON DELETE CASCADE,
  server_fingerprint_hash text NOT NULL,
  activated_at timestamptz NOT NULL DEFAULT now(),
  last_checked_at timestamptz,
  deactivated_at timestamptz,
  UNIQUE(license_id, server_fingerprint_hash)
);
CREATE TABLE backups (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  node_id uuid REFERENCES nodes(id) ON DELETE SET NULL,
  kind text NOT NULL CHECK (kind IN ('database','config','full')),
  storage_uri text NOT NULL,
  checksum_sha256 text,
  encrypted boolean NOT NULL DEFAULT true,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','running','completed','failed')),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  recipient_type text NOT NULL,
  recipient_id uuid,
  channel text NOT NULL,
  template_key text,
  payload jsonb NOT NULL DEFAULT '{}'::jsonb,
  status text NOT NULL DEFAULT 'queued' CHECK (status IN ('queued','sent','failed','read')),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE message_templates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  key text NOT NULL,
  locale text NOT NULL DEFAULT 'fa',
  channel text NOT NULL,
  subject text,
  body text NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(key, locale, channel)
);
CREATE TABLE event_outbox (
  id bigserial PRIMARY KEY,
  event_type text NOT NULL,
  aggregate_type text NOT NULL,
  aggregate_id text NOT NULL,
  payload jsonb NOT NULL,
  occurred_at timestamptz NOT NULL DEFAULT now(),
  published_at timestamptz
);
CREATE INDEX event_outbox_unpublished_idx ON event_outbox(id) WHERE published_at IS NULL;
