module github.com/otaredvpn/otaredvpn/apps/master

go 1.22

require (
    github.com/jackc/pgx/v5 v5.7.2
    github.com/redis/go-redis/v9 v9.7.0
)
