# otared-node (Phase 1 placeholder)

The node agent is intentionally not operational yet. Phase 2 will implement authenticated enrollment, mTLS identity, core lifecycle management, config application, health reporting, and usage-stat streaming. Never run a node agent that accepts unauthenticated master commands.
