export default function Home() {
  return (
    <main>
      <h1>OTaredVPN</h1>
      <p>اسکلت اولیه پنل — فاز اول</p>
      <p>رابط کاربری و امکانات مدیریتی در فازهای بعدی پیاده‌سازی می‌شوند.</p>
    </main>
  );
}
