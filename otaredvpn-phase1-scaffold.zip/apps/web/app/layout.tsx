export const metadata = {
  title: "OTaredVPN",
  description: "VPN management and reseller platform",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="fa" dir="rtl">
      <body style={{ fontFamily: "system-ui", margin: 0, padding: "2rem" }}>{children}</body>
    </html>
  );
}
