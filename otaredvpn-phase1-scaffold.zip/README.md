# OTaredVPN — Phase 1 scaffold

OTaredVPN is a planned commercial VPN management and reseller platform inspired by the operational workflows of Sanaei/3x-ui and Pasargad-style panels. This repository is a **Phase 1 scaffold**, not a production-ready VPN panel.

## Current scope
- Go master API with `/healthz` and `/readyz`
- PostgreSQL and Redis development services
- Initial relational schema migration
- Master↔node gRPC contract draft
- Next.js frontend placeholder
- Architecture/security/data-model documentation
- Make targets for local development

## Requirements
- Docker Engine + Docker Compose plugin
- Go 1.22+
- Node.js 20+ (only needed to run web locally outside Compose)

## Quick start
1. Copy `.env.example` to `.env` and change all sample secrets for any non-local use.
2. Run `make dev`.
3. Check `http://localhost:8080/healthz` and `http://localhost:8080/readyz`.
4. Stop with `make down`.

The current Compose setup is intended for local development only. Do not expose it to the public internet.

## Important limitations
The schema and proto are an initial design baseline. Authentication, RBAC enforcement, node mTLS enrollment, real core management, traffic accounting, payment integrations, licensing enforcement, installer hardening, and production frontend are not implemented in this phase.
